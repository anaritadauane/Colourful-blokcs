﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WhereIsKetnipz
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        List<string> images = new List<string>() { "first", "second", "mainone" };


        int timerCount = 0;
        int score = 0; // the score variable 
        int level = 0; // level of the game 
        int lives = 3; // starting number of games  
        Brush statusTxtColor;
        DispatcherTimer timer = new DispatcherTimer();

        public Window1()
        {
            InitializeComponent();
            enableCard(false);
            Textbox.Text = "";
            timer.Tick += Timer_Tick;
            timer.Interval = new TimeSpan(0, 0, 0, 0, 2000);
            img_01.Source = img_02.Source = img_03.Source = getImage("back001");
            img_04.Visibility = Visibility.Hidden;            //Hides the cards
            img_05.Visibility = Visibility.Hidden;
            img_06.Visibility = Visibility.Hidden;




        }


        private BitmapImage getImage(string img)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri("images/" + img + ".png", UriKind.Relative);
            image.EndInit();
            return image;
        }
        private void Shuffle(List<string> imagelist) // Shuffles the list 
        {
            Random random = new Random();
            int n = imagelist.Count;
            for (int i = 0; i < n; i++)
            {
                int r = i + random.Next(n - i);
                string t = imagelist[r];
                imagelist[r] = imagelist[i];
                imagelist[i] = t;
            }
            images = imagelist;

        }

        private void Openimg()
        {
            img_01.Source = getImage(images[0]);
            img_02.Source = getImage(images[1]);
            img_03.Source = getImage(images[2]);

            if (level == 1)
            {
                img_04.Source = getImage(images[3]);
                img_05.Source = getImage(images[4]);
                img_06.Source = getImage(images[5]);
            }

            
        }

        private void finShuffle()
        {
            timer.Stop();
            img_01.Source = img_02.Source = img_03.Source = getImage("back001");

            if (level == 1)
            {
                img_01.Source = img_02.Source = img_03.Source = img_04.Source = img_05.Source = img_06.Source = getImage("back001");


            }
            
            timerCount = 0;
            Go_bbn_.IsEnabled = true;
            enableCard(true);
        }

        private void enableCard(bool enable)
        {
            img_01.IsEnabled = img_02.IsEnabled =img_03.IsEnabled = img_04.IsEnabled = img_05.IsEnabled = img_06.IsEnabled = enable;
        }
        private void Timer_Tick(object sender, EventArgs e) // event handler according to the time to shuffle 
        {
            setCard();
        }
        
        private void setCard() //  set the image to an random position using the method shuffle and closing the image 
        {
            timerCount++;
            Shuffle(images);
            timer.Stop();
            if (timerCount < 8)
            {
                timer.Start();
                Openimg();
                

            }
            else
            {
                
                finShuffle();
            }
            
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {

           
            Openimg();
            enableCard(false);
            Image card = (Image)sender;
            char[] splitChar = { '_' };
            string[] numberString = card.Name.Split(splitChar);
            int cardNumber = int.Parse(numberString[1]);
            checkResult(cardNumber);

            
        }

        private void checkResult(int number)
        {


            string result = "";
            int t = 100;
            

            if (images[number-1] == "mainone")
            {
                statusTxtColor = Brushes.GreenYellow;
                result = "You won !!!";
                score += 10;
                t = 100 + t;

                if (score >= 10)
                {
                    timer.Interval = new TimeSpan(0, 0, 0, 0, 1000 + t);
                    level += 1;
                }

            }
            else
            {
                statusTxtColor = Brushes.Red;
                result = "Wrong, try again.";
                score -= 5;
                lives--;

                if (lives == 0)
                {
                    result = "Game Over, START NEW GAME";
                    MessageBox.Show("Game Over, Start Again");
                    
                    //Window1.Visibility = Visibility.Hidden;
                    timer.Stop();
                    lives = 3;
                    this.Close();
                }
            }
            Textbox.Foreground = statusTxtColor;
            Textbox.Text = result;
            scoretxt_.Text = "Score " + score.ToString();
            leveltext_.Text = "Level " + level.ToString();
            livestxt_.Text = "Lives " + lives.ToString();
            
        }
    

        private void Go_bbn__Click(object sender, RoutedEventArgs e)
        {
            timer.Start();

            if (level == 1)
            {
                images.Add("kept004");
                images.Add("ket");
                images.Add("keptniz");
                img_04.Visibility = Visibility.Visible;
                img_05.Visibility = Visibility.Visible;
                img_06.Visibility = Visibility.Visible;

            }

            statusTxtColor = Brushes.White;
            Textbox.Foreground = statusTxtColor;
            Textbox.Text = "Wait";
            enableCard(false);
            Go_bbn_.IsEnabled = false;

            
            
        }

        private void Textbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
