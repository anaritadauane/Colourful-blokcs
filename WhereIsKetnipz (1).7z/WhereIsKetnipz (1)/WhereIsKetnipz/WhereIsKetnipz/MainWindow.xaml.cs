﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WhereIsKetnipz
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            Close();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("The name of this game is Where is Ketnipz. It is a guessing game. The card you are expected to find is the purple ketnipz. The cards will be made visible when you press start. The purple ketnipz will be shuffled visibly, the cards will be closed then the purple Ketnipz will be shuffled while the cards are hidden. When all the cards are hidden, click on the card that you think is correct. If you are correct, you earn 10 points and level up. If you are incorrect you lose 5 point and lose a life. If you lose all 3 lives, it is game over. You will have to start a new game.");
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
