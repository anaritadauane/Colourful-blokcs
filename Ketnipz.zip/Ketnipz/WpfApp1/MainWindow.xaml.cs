﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<string> images = new List<string>() { "card2", "card1", "mainkept" };
        
      
        int timerCount = 0;
        int score = 0;
        int level = 0;
        int lives = 3;
        Brush statusTxtColor;
        DispatcherTimer timer = new DispatcherTimer();
        
        public MainWindow()
        {
            InitializeComponent();
            enableCard(false);
            statusTxt.Text = "";
            timer.Tick += Timer_Tick;
            timer.Interval = new TimeSpan(0,0,0,0,1000);
            qLbl1.Visibility = qLbl2.Visibility = qLbl3.Visibility = Visibility.Collapsed;
            card_0.Source = card_1.Source = card_2.Source = getImage("back001");
            card_3.Visibility = Visibility.Hidden;
            card_4.Visibility = Visibility.Hidden;
            card_5.Visibility = Visibility.Hidden;
            card_6.Visibility = Visibility.Hidden;
            card_7.Visibility = Visibility.Hidden;
            card_8.Visibility = Visibility.Hidden;

            if (level == 1)
            {

                card_3.Source = card_4.Source = card_5.Source = getImage("back001");

            }
            if (level == 2)
            {
                card_6.Source = card_7.Source = card_8.Source = getImage("back001");
            }
        }

        // Timer tick
        private void Timer_Tick(object sender, EventArgs e)
        {
            setCard();
        }
        // Place card
        private void setCard()
        {
            timerCount++;
            Shuffle(images);
            if (timerCount < 8)
            {
                openCard();
            }
            else
            {
                endShuffle();
            }
        }

        //Get image
        private BitmapImage getImage(string img)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri("images/" + img + ".png",UriKind.Relative);
            image.EndInit();
            return image;
        }
        // End shuffle
        private void endShuffle()
        {
            card_0.Source = card_1.Source = card_2.Source = getImage("back001");

            if (level == 1)
            {
                card_0.Source = card_1.Source = card_2.Source = card_3.Source = card_4.Source = card_5.Source = getImage("back001");


            }
            if (level ==2)
            {
                card_0.Source = card_1.Source = card_2.Source = card_3.Source = card_4.Source = card_5.Source = card_6.Source = card_7.Source = card_8.Source  = getImage("back001");
            }
            //qLbl1.Visibility = qLbl2.Visibility = qLbl3.Visibility = Visibility.Visible;
            statusTxt.Text = "Find Keptniz";
            timer.Stop();
            timerCount = 0;
            startBtn.IsEnabled = true;
            enableCard(true);
        }

        //Shufle array
        private void Shuffle(List<string> imagelist)
        {
            Random random = new Random();
            int n = imagelist.Count;  
            for (int i = 0; i < n;  i++) 
            {               
                int r = i + random.Next(n - i); 
                string t = imagelist[r];  
                imagelist[r] = imagelist[i];
                imagelist[i] = t;
            }
            images = imagelist;
        }     
        //Click card event
        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {


            openCard();
            enableCard(false);
            Image card =(Image) sender;
            char[] splitChar =  { '_' };
            string[] numberString = card.Name.Split(splitChar);
            int cardNumber = int.Parse(numberString[1]);
            checkResult(cardNumber);

           
        }

        // Check result
        private void checkResult(int number)
        {


            string result = "";
            int t = 100;
            
                if (images[number] == "mainkept")
                {
                    statusTxtColor = Brushes.GreenYellow;
                    result = "You won !!!";
                    score += 10;
                    t = 100 + t;

                    if (score >= 10)
                    {
                        timer.Interval = new TimeSpan(0, 0, 0, 0, 1000 + t);
                        level += 1;
                    }
                    

                }
                else
                {
                    statusTxtColor = Brushes.Red;
                    result = "Wrong, try again.";
                    score -= 5;
                    lives--;

                    if (lives == 0)
                    {
                        result = "Game Over, START NEW GAME";
                        MessageBox.Show("Game Over, START NEW GAME");
                        timer.Stop();
                       //break();
                    }
                }
                statusTxt.Foreground = statusTxtColor;
                statusTxt.Text = result;
                scoreTxt.Text = "Score: " + score.ToString();
                leveltxt.Text = "Level: " + level.ToString();
                Livestxt.Text = "Lives: " + lives.ToString();
            //}
        }

        private void startBtn_Click(object sender, RoutedEventArgs e)
        {
            



            timer.Start();
            

            if (level == 1)
            {
                images.Add("kept");
                images.Add("ket");
                images.Add("keptniz");
                card_3.Visibility = Visibility.Visible;
                card_4.Visibility = Visibility.Visible;
                card_5.Visibility = Visibility.Visible;

            }

            if (level == 2)
            {
                images.Add("k1");
                images.Add("k2");
                images.Add("k3");

                card_6.Visibility = Visibility.Visible;
                card_7.Visibility = Visibility.Visible;
                card_8.Visibility = Visibility.Visible;


            }
            statusTxtColor = Brushes.White;
            statusTxt.Foreground = statusTxtColor;
            statusTxt.Text = "Wait";
            enableCard(false);
            startBtn.IsEnabled = false;
            
        }

       
        private void enableCard( bool enable )
        {
            card_0.IsEnabled = card_1.IsEnabled = card_2.IsEnabled = card_3.IsEnabled = card_4.IsEnabled = card_5.IsEnabled = card_6.IsEnabled = card_7.IsEnabled = card_8.IsEnabled = enable;
        }


        //Open card
        private void openCard()
        {
            card_0.Source = getImage(images[0]);
            card_1.Source = getImage(images[1]);
            card_2.Source = getImage(images[2]);

            if (level == 1)
            {
                card_3.Source = getImage(images[3]);
                card_4.Source = getImage(images[4]);
                card_5.Source = getImage(images[5]);
            }

            if (level == 2)
            {
                card_6.Source = getImage(images[6]);
                card_7.Source = getImage(images[7]);
                card_8.Source = getImage(images[8]);
            }
        }
        // Close card
        private void closeCard()
        {
            card_0.Source = card_1.Source = card_2.Source = getImage("back001");

            if (level == 1)
            {
                card_3.Source = card_4.Source = card_5.Source = getImage("back001");

            }

            if (level == 2)
            {
                card_6.Source = card_7.Source = card_8.Source = getImage("back001");

            }
        }

    }
}
