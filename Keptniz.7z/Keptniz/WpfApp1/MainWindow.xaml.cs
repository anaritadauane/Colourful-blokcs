﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<string> images = new List<string>() { "card1", "card1", "mainkept" };
        
       /* images = { "card1", "card1", "mainkept" }*/
        int timerCount = 0;
        int score = 0;
        int level = 1;
        Brush statusTxtColor;
        DispatcherTimer timer = new DispatcherTimer();
        
        public MainWindow()
        {
            InitializeComponent();
            enableCard(false);
            statusTxt.Text = "";
            timer.Tick += Timer_Tick;
            timer.Interval = new TimeSpan(0,0,0,0,200);
            qLbl1.Visibility = qLbl2.Visibility = qLbl3.Visibility = Visibility.Collapsed;
            card_0.Source = card_1.Source = card_2.Source = getImage("back001");            
        }

        // Timer tick
        private void Timer_Tick(object sender, EventArgs e)
        {
            setCard();
        }
        // Place card
        private void setCard()
        {
            timerCount++;
            Shuffle(images);
            if (timerCount < 8)
            {
                openCard();
            }
            else
            {
                endShuffle();
            }
        }

        //Get image
        private BitmapImage getImage(string img)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri("images/" + img + ".png",UriKind.Relative);
            image.EndInit();
            return image;
        }
        // End shuffle
        private void endShuffle()
        {
            card_0.Source = card_1.Source = card_2.Source = getImage("back001");
            qLbl1.Visibility = qLbl2.Visibility = qLbl3.Visibility = Visibility.Visible;
            statusTxt.Text = "Find Keptniz";
            timer.Stop();
            timerCount = 0;
            startBtn.IsEnabled = true;
            enableCard(true);
        }

        //Shufle array
        private void Shuffle(List<string> imagelist)
        {
            Random random = new Random();
            int n = imagelist.Count;  
            for (int i = 0; i < n;  i++) 
            {               
                int r = i + random.Next(n - i); 
                string t = imagelist[r];  
                imagelist[r] = imagelist[i];
                imagelist[i] = t;
            }
            images = imagelist;
        }     
        //Click card event
        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            openCard();
            enableCard(false);
            Image card =(Image) sender;
            char[] splitChar =  { '_' };
            string[] numberString = card.Name.Split(splitChar);
            int cardNumber = int.Parse(numberString[1]);
            checkResult(cardNumber);          
        }

        // Check result
        private void checkResult(int number)
        {


            string result = "";
           
            if (images[number] == "mainkept")
            {
                statusTxtColor = Brushes.GreenYellow;
                result = "You won !!!";
                score += 10;
                if (score <= 10)
                {
                    timer.Interval = new TimeSpan(0, 0, 0, 0, 200+100);
                    level += 1; 
                }
                if (score <= 20)
                {
                 

                }

            }
            else
            {
                statusTxtColor = Brushes.Red;
                result = "Sorry, you lost.";
                score -= 5;
                if (score <= 0)
                {
                    result = "Game Over, TRY AGAIN";
                    

                }
            }
            statusTxt.Foreground = statusTxtColor;
            statusTxt.Text = result;
            scoreTxt.Text ="Score: "+ score.ToString();
            leveltxt.Text = "Level: " + level.ToString(); 

        }

        private void startBtn_Click(object sender, RoutedEventArgs e)
        {
            timer.Start();
            statusTxtColor = Brushes.White;
            statusTxt.Foreground = statusTxtColor;
            statusTxt.Text = "Wait";
            enableCard(false);
            startBtn.IsEnabled = false;
         //   startBtn.Visibility = Visibility.Hidden;
            //qLbl1.Visibility = qLbl2.Visibility = qLbl3.Visibility = Visibility.Collapsed;
        }

        // Enable card click
        private void enableCard( bool enable )
        {
            card_0.IsEnabled = card_1.IsEnabled = card_2.IsEnabled = enable;
        }


        //Open card
        private void openCard()
        {
            card_0.Source = getImage(images[0]);
            card_1.Source = getImage(images[1]);
            card_2.Source = getImage(images[2]);
            //card_1_Copy.Source = getImage(images[0]);
            //card_0_Copy1.Source = getImage(images[1]);
            //card_0_Copy.Source = getImage(images[0]);
        }
        // Close card
        private void closeCard()
        {
            card_0.Source = card_1.Source = card_2.Source = getImage("back001");
        }

    }
}
